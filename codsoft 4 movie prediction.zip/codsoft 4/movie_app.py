from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor
import pandas as pd
import numpy as np
import streamlit as st
import pickle 

## loading the model
pickle_out =open('GradientBoostingregressor.pkl', 'rb')
pickle_model = pickle.load(pickle_out)

## loading the encoder file
with open('actor 1.pkl','rb') as encoder_file:
    encoded_actor1 = pickle.load(encoder_file)

with open('actor 2.pkl','rb') as encoder_file:
    encoded_actor2 = pickle.load(encoder_file)

with open('actor 3.pkl','rb') as encoder_file:
    encoded_actor3 = pickle.load(encoder_file)

with open('director.pkl', 'rb') as encoder_file:
    encoded_director = pickle.load(encoder_file)

with open('genre.pkl', 'rb') as encoder_file:
    encoded_genre = pickle.load(encoder_file)

with open('name.pkl', 'rb') as encoder_file:
    encoded_name = pickle.load(encoder_file)


## loading the dataframe
dataset = pd.read_csv('indian movies.csv')
## Feature nam
feature_name = [['Name','Director','Actor 1','Actor 2','Actor 3','Genre','Duration','Votes']]

## target variable
target_name=dataset['Rating']

## app creation
st.title('MOVIE RATING PREDICTION APP')


name = st.selectbox('Movie Name:', dataset['Name'].unique())
directors = st.selectbox('Director Name:', dataset['Director'].unique())
actor_1 = st.selectbox('Actor_1 Name:', dataset['Actor 1'].unique())
actor_2 = st.selectbox('Actor_2 Name:', dataset['Actor 2'].unique())
actor_3 = st.selectbox('Actor_3 Name:', dataset['Actor 3'].unique())
genre = st.selectbox('Genre', dataset['Genre'].unique())
Duration = st.selectbox('Duration', dataset['Duration'].unique())
Votes = st.selectbox('Votes', dataset['Votes'].unique())

movie = dataset[
    (dataset['Name'] == name) &(dataset['Director'] == directors) &(dataset['Genre'] == genre) &
    (dataset['Actor 1'] == actor_1) &(dataset['Actor 2'] == actor_2) &(dataset['Actor 3'] == actor_3) &
    (dataset['Duration'] == Duration) &(dataset['Votes'] == Votes) 
]


if st.button('Predict'):
    encoder_name = encoded_name.transform([name])[0]
    encoder_director = encoded_director.transform([directors])[0]
    encoder_actor1 = encoded_actor1.transform([actor_1])[0]
    encoder_actor2 = encoded_actor2.transform([actor_2])[0]
    encoder_actor3 = encoded_actor3.transform([actor_3])[0]
    encoder_genre = encoded_genre.transform([genre])[0]

    if not movie.empty:
        X = np.array([[encoder_name,encoder_director,encoder_actor1,encoder_actor2,encoder_actor3,encoder_genre,Duration,Votes]])
        Rating = pickle_model.predict(X)
        st.success(f'review rating is {Rating[0]:.1f}')
    else:
        st.warning('Invalid Check input data')